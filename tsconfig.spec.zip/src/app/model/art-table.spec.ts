import { ArtTable } from './art-table';

describe('ArtTable', () => {
  it('should create an instance', () => {
    expect(new ArtTable()).toBeTruthy();
  });
});
