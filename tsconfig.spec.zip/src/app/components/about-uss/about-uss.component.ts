import { Component } from '@angular/core';

@Component({
  selector: 'app-about-uss',
  standalone: true,
  imports: [],
  templateUrl: './about-uss.component.html',
  styleUrl: './about-uss.component.css'
})
export class AboutUssComponent {

}
