import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateLifeComponent } from './private-life.component';

describe('PrivateLifeComponent', () => {
  let component: PrivateLifeComponent;
  let fixture: ComponentFixture<PrivateLifeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrivateLifeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrivateLifeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
