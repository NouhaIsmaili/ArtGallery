import { Component } from '@angular/core';

@Component({
  selector: 'app-catrine-alexandre',
  standalone: true,
  imports: [],
  templateUrl: './catrine-alexandre.component.html',
  styleUrl: './catrine-alexandre.component.css'
})
export class CatrineAlexandreComponent {

}
