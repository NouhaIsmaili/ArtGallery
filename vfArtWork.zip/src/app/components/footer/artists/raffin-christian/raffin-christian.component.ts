import { Component } from '@angular/core';

@Component({
  selector: 'app-raffin-christian',
  standalone: true,
  imports: [],
  templateUrl: './raffin-christian.component.html',
  styleUrl: './raffin-christian.component.css'
})
export class RaffinChristianComponent {

}
