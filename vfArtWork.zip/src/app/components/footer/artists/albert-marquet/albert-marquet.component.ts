import { Component } from '@angular/core';

@Component({
  selector: 'app-albert-marquet',
  standalone: true,
  imports: [],
  templateUrl: './albert-marquet.component.html',
  styleUrl: './albert-marquet.component.css'
})
export class AlbertMarquetComponent {

}
