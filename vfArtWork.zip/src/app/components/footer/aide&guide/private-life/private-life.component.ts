import { Component } from '@angular/core';

@Component({
  selector: 'app-private-life',
  standalone: true,
  imports: [],
  templateUrl: './private-life.component.html',
  styleUrl: './private-life.component.css'
})
export class PrivateLifeComponent {

}
