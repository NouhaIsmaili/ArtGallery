import { StarPipe } from './star.pipe';

describe('StarPipe', () => {
  it('create an instance', () => {
    const pipe = new StarPipe();
    expect(pipe).toBeTruthy();
  });
});
