import { Component } from '@angular/core';

@Component({
  selector: 'app-leonard-de-vinci',
  standalone: true,
  imports: [],
  templateUrl: './leonard-de-vinci.component.html',
  styleUrl: './leonard-de-vinci.component.css'
})
export class LeonardDeVinciComponent {

}
