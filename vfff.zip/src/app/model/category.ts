export enum Category {
    abstrait="Abstrait",
    classique="classique",
    fauve="Fauve",
    figuratif="figuratif",
    pop_art="pop_art"
}
